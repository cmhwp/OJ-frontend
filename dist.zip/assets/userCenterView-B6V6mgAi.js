import{_ as e,o as c,c as r}from"./index-CmPgxPM7.js";const n={};function t(o,a){return c(),r("div",null," dada ")}const _=e(n,[["render",t]]);export{_ as default};
